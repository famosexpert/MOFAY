import { useState, useEffect } from "react";
import { HashRouter, Routes, Route, NavLink, Link, useLocation } from "react-router-dom";
import { site, nav, icons, services, skills, projects, socials, heroArt } from "./data.js";

const Icon = ({ d }) => <svg viewBox="0 0 24 24" aria-hidden="true"><path d={d} /></svg>;
const base = import.meta.env.BASE_URL;
const Socials = () => (
  <div className="social">{socials.map(s => <a key={s.name} href={s.url} target="_blank" rel="noopener noreferrer"><Icon d={s.icon} />{s.name}</a>)}</div>
);
const Reveal = ({ children }) => <div className="wrap reveal">{children}</div>;
const PageHead = ({ k, t, lead }) => (
  <section className="pagehead"><Reveal><div className="kicker">{k}</div><h1>{t}</h1>{lead && <p className="lead">{lead}</p>}</Reveal></section>
);
const Block = ({ alt, k, t, children }) => (
  <section className={alt ? "alt" : ""}><Reveal><div className="kicker">{k}</div><h2>{t}</h2>{children}</Reveal></section>
);
const Grid = ({ items }) => (
  <div className="grid">{items.map(s => <div className="card reveal" key={s.title}><div className="ic"><Icon d={icons[s.icon]} /></div><h3>{s.title}</h3><p>{s.text}</p></div>)}</div>
);
const Cta = () => (
  <section><div className="wrap"><div className="cta reveal"><h2>Have an idea? Let's build something useful.</h2><p>Tell me what you have in mind and let's talk.</p><Link className="btn" to="/contact">Contact Me</Link></div></div></section>
);

function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header><div className="wrap">
      <Link to="/" className="logo">MOF</Link>
      <button className="menu" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}><Icon d="M3 6h18M3 12h18M3 18h18" /></button>
      <nav className={open ? "open" : ""} onClick={() => setOpen(false)}>
        {nav.map(([l, s]) => <NavLink key={l} to={"/" + s} end className={({ isActive }) => (isActive ? "active" : "")}>{l}</NavLink>)}
      </nav>
    </div></header>
  );
}

const Home = () => (<>
  <section className="hero"><div className="wrap">
    <div>
      <div className="eyebrow">{site.title}</div><h1>{site.name}</h1>
      <p style={{ fontSize: "1.4rem", fontWeight: 600 }}>{site.headline}</p>
      <p className="lead" style={{ marginTop: 12 }}>{site.intro}</p>
      <div className="btns"><Link className="btn fill" to="/portfolio">Explore My Work</Link><Link className="btn line" to="/contact">Contact Me</Link></div>
    </div>
    <div className="hero-art" role="img" aria-label="Illustration of a computer, laptop, phone and network" dangerouslySetInnerHTML={{ __html: heroArt }} />
  </div></section>
  <Block alt k="WHAT I DO" t="Services & Interests"><Grid items={services.slice(0, 4)} /><Link className="more" to="/services">View all services</Link></Block>
  <Block k="ABOUT ME" t={site.aboutTitle}><div className="about"><p>{site.about[1]}</p></div><Link className="more" to="/about">More about me</Link></Block>
  <Cta />
</>);

const About = () => (<>
  <PageHead k="ABOUT ME" t={site.aboutTitle} />
  <section><Reveal><div className="about-grid">
    <div className="photo">MF<img src={base + site.photo} alt={"Portrait of " + site.name} width="300" height="375" loading="lazy" onError={e => (e.currentTarget.style.display = "none")} /></div>
    <div className="about">{site.about.map((p, i) => <p key={i}>{p}</p>)}</div>
  </div></Reveal></section>
  <Cta />
</>);

const Services = () => (<>
  <PageHead k="SERVICES & INTERESTS" t="What I Work On" lead="The areas I work in and keep learning about." />
  <section><Reveal><Grid items={services} /></Reveal></section><Cta />
</>);

const Skills = () => (<>
  <PageHead k="SKILLS & LEARNING" t="Always Learning" lead="Skills I am building and growing." />
  <section><Reveal><div className="chips" style={{ marginTop: 0 }}>{skills.map(s => <span className="chip" key={s}>{s}</span>)}</div></Reveal></section><Cta />
</>);

const Portfolio = () => (<>
  <PageHead k="PORTFOLIO" t="Selected Projects" lead="My work will appear here as I complete and add projects." />
  <section><Reveal><div className="grid">{projects.map(p => (
    <div className="card reveal" key={p.title}>
      <div className="thumb">{p.image ? <img src={base + p.image} alt={p.title} loading="lazy" /> : "Project image placeholder"}</div>
      <div className="tag">{p.category}</div><h3>{p.title}</h3><p>{p.text}</p>
      {p.link && <a className="more" href={p.link}>View details</a>}
    </div>))}</div></Reveal></section>
</>);

function Contact() {
  const send = e => {
    e.preventDefault();
    const f = new FormData(e.target);
    window.location.href = `mailto:${site.email}?subject=${encodeURIComponent("Message from " + f.get("n"))}&body=${encodeURIComponent(f.get("m") + "\n\n" + f.get("n") + " (" + f.get("e") + ")")}`;
  };
  return (<>
    <PageHead k="CONTACT" t="Let's Talk" lead="Have an idea or a question? Reach out on any of these, or send a message." />
    <section><Reveal><div className="cwrap">
      <div>
        <a className="card" href={"mailto:" + site.email}><h3>Email</h3><p>{site.email}</p></a>
        <a className="card" href={site.whatsapp} target="_blank" rel="noopener noreferrer"><h3>WhatsApp</h3><p>{site.whatsappLabel}</p></a>
        <Socials />
      </div>
      <form className="cform" onSubmit={send}>
        <label>Name<input name="n" required /></label>
        <label>Email<input type="email" name="e" required /></label>
        <label>Message<textarea name="m" rows="5" required /></label>
        <button className="btn fill" type="submit">Send Message</button>
      </form>
    </div></Reveal></section>
  </>);
}

function Shell() {
  const { pathname } = useLocation();
  useEffect(() => {
    const item = nav.find(([, s]) => "/" + s === pathname);
    document.title = (item && item[1] ? item[0] + " | " : "") + site.name + " | " + site.title;
    window.scrollTo(0, 0);
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && e.target.classList.add("in")), { threshold: .12 });
    document.querySelectorAll(".reveal").forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [pathname]);
  return (<>
    <Header />
    <main><Routes>
      <Route path="/" element={<Home />} /><Route path="/about" element={<About />} />
      <Route path="/services" element={<Services />} /><Route path="/skills" element={<Skills />} />
      <Route path="/portfolio" element={<Portfolio />} /><Route path="/contact" element={<Contact />} />
      <Route path="*" element={<Home />} />
    </Routes></main>
    <footer><div className="wrap">
      <nav>{nav.map(([l, s]) => <Link key={l} to={"/" + s}>{l}</Link>)}</nav>
      <p style={{ marginTop: 18 }}>© 2026 {site.name}. All Rights Reserved.</p>
    </div></footer>
  </>);
}

export default function App() { return <HashRouter><Shell /></HashRouter>; }
