Put your portrait here as photo.jpg (about 800px wide, under 200 KB).
